import os
import unittest
from unittest import mock

import ai
from hydra_dsl import parse_command

PY_TRACE = """Запускаю бота и падает:
Traceback (most recent call last):
  File "/workspaces/hydra-mark4/main.py", line 3, in <module>
    import requests
  File "/usr/lib/python3.12/site-packages/x.py", line 1, in <module>
ModuleNotFoundError: No module named 'requests'
"""

JS_TRACE = """Uncaught TypeError: Cannot read properties of undefined (reading 'map')
    at App (src/App.js:12:5)
    at node_modules/react/index.js:1:1"""


class TestRules(unittest.TestCase):
    def test_python_traceback(self):
        lines = ai.rules_translate(PY_TRACE)
        first = parse_command(lines[0])
        self.assertEqual(first["operation"], "ANALYZE")
        self.assertEqual(first["target"], "python")
        self.assertEqual(first["params"]["error"], "ModuleNotFoundError")
        self.assertEqual(first["params"]["message"], "No module named 'requests'")
        self.assertEqual(first["params"]["file"], "/workspaces/hydra-mark4/main.py")
        self.assertEqual(first["params"]["line"], "3")
        self.assertEqual(len(lines), 1)

    def test_name_error_adds_search(self):
        lines = ai.rules_translate("NameError: name 'greet' is not defined. Did you mean: 'great'?")
        self.assertEqual(parse_command(lines[1])["params"]["query"], "greet")

    def test_js_traceback(self):
        first = parse_command(ai.rules_translate(JS_TRACE)[0])
        self.assertEqual(first["target"], "javascript")
        self.assertEqual(first["params"]["file"], "src/App.js")

    def test_no_error(self):
        lines = ai.rules_translate("Не работает функция `analyze_text` в файле main.py")
        ops = [parse_command(x)["operation"] for x in lines]
        self.assertEqual(ops, ["INSPECT", "SEARCH"])

    def test_plain_text(self):
        first = parse_command(ai.rules_translate("всё сломалось")[0])
        self.assertEqual(first["target"], "unknown")


class TestTranslate(unittest.TestCase):
    def test_fallback_without_key(self):
        with mock.patch.dict(os.environ, {"OPENAI_API_KEY": "", "HYDRA_AI_PROVIDER": "openai"}):
            commands, info = ai.translate(PY_TRACE)
        self.assertEqual(info["provider"], "rules")
        self.assertTrue(info["warnings"])
        self.assertEqual(commands[0]["operation"], "ANALYZE")

    def test_openai_failure_falls_back(self):
        with mock.patch.dict(os.environ, {"OPENAI_API_KEY": "test"}), \
                mock.patch.object(ai, "_from_openai", side_effect=RuntimeError("boom")):
            commands, info = ai.translate(PY_TRACE, provider="openai")
        self.assertEqual(info["provider"], "rules")
        self.assertIn("boom", info["warnings"][0])

    def test_openai_success(self):
        fake = [parse_command("ANALYZE python error=NameError")]
        with mock.patch.object(ai, "_from_openai", return_value=fake):
            commands, info = ai.translate("x", provider="openai")
        self.assertTrue(info["provider"].startswith("openai/"))
        self.assertEqual(info["dsl"], ["ANALYZE python error=NameError"])

    def test_empty(self):
        commands, info = ai.translate("   ")
        self.assertEqual(commands, [])


if __name__ == "__main__":
    unittest.main()
